package com.example.formdata;

public class GoalForm {
    private String time;
    private int player;

    public int getPlayer() { return player; }

    public void setPlayer(int player) { this.player = player; }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
